# PPOMS Web系统 架构设计文档 (V1.0)

## 1. 系统概述
PPOMS (Procurement Production Operation Management System) Web版旨在将原有的桌面端单机应用平滑升级为支持多用户、权限分离的企业级应用。
**部署环境**: 生产环境搭建在 **Ubuntu** 操作系统上。
**演进策略**: 考虑到系统功能庞大，系统架构采用 **微内核/模块化单体架构 (Modular Monolith)**，而非初期就上重型的微服务架构。通过模块解耦，实现**循序渐进、增量迭代**。新模块的上线通过打包脚本进行热插拔或平滑发布，确保绝不影响已上线模块的正常运行，并提供**一键回退**机制。

## 2. 技术架构

### 2.1 总体架构
采用前后端分离架构，后端基于 Spring Boot 3.x 采用模块化单体设计（方便后期向微服务拆分），前端基于 Vue 3 + Element Plus。

*   **前端**: Vue 3, Vite, TypeScript, Pinia (状态管理), Element Plus (UI组件库), Echarts (数据可视化).
*   **后端**: Java 17+, Spring Boot 3.x (Modular Monolith), MyBatis-Plus, Spring Security + JWT.
*   **数据库**: MySQL 8.0 (继承自 SQLite 的平移结构).
*   **缓存**: Redis (用于缓存 Token、字典数据、智能推荐规则).
*   **部署环境**: Ubuntu Server 22.04 LTS 或更高版本.
*   **发布管理**: 采用 Bash/Shell 脚本实现自动化打包、增量部署与快速回退。

### 2.2 模块划分 (Modular Design)
为支持增量迭代，后端代码按业务域严格划分模块（Maven/Gradle Multi-module）：
1.  **Core 核心模块 (启动基石)**: 包含 Spring Security 认证、RBAC 权限管理、公共配置、日志拦截等。
2.  **Plan 采购计划模块 (首批上线)**: 月度计划导入、采购申请、智能推荐字典、计划下达。
3.  **Progress 进度与执行模块 (二期迭代)**: 计划状态流转、Echarts 进度大屏、树形级联更新。
4.  **Supply 供应链模块 (三期迭代)**: 合同台账、执行订单、入库登记联动。
5.  **AI Gateway 智能模块 (独立插件)**: 统一对接 DeepSeek/Kimi 等大模型，作为独立模块挂载。

## 3. 核心业务流程设计

### 3.1 用户与权限体系 (RBAC)
*   **部门划分**: 支持多层级部门管理，其中“生产管理部”为核心采购业务部门。
*   **角色体系**:
    *   **录入员 (各部门)**: 负责录入本部门的采购需求数据，上传线下审批报告 (PDF)。
    *   **部门经理 (各部门)**: 可以看到本部门的所有采购需求数据及进度情况。
    *   **采购经理 (生产管理部)**: 拥有全局视角，可以看到所有部门提交的采购需求。负责审核需求、修改明细、更新审批报告、将明细分配给具体采购员，并最终确认发放。
    *   **采购员 (生产管理部)**: 只能看到被分配给自己**且已由采购经理确认发放**的采购任务明细（未发放前绝对不可见）。
    *   **系统管理员**: 负责系统基础配置与用户角色分配。
*   **数据权限拦截**:
    *   通过拦截器或 MyBatis-Plus 数据权限插件，动态追加 SQL `WHERE` 条件，实现不同角色对数据的行级过滤。

### 3.2 采购主流程
1.  **计划导入**: 生产部导入月度物资需求计划 (Excel) -> 生成 `MonthlyPlan`.
2.  **任务分配**: 采购经理将计划项分配给具体采购员 -> 生成 `PurchaseTask`.
3.  **询价/核价**: 采购员录入询价结果 -> 系统自动比对历史价格/标准价 -> 经理审批.
4.  **合同/订单**: 确认价格后生成采购合同或直接生成采购订单 (`PurchaseOrder`).
5.  **入库**: 物资到货，库管员关联订单进行入库录入 -> 生成 `InboundRecord` (扣减订单未执行数量).
6.  **发票**: 采购员收到发票，录入并关联入库单 -> 生成 `Invoice`.
7.  **对账**: 定期生成对账单 (`Reconciliation`) -> 供应商确认.
8.  **结算**: 财务付款 -> 更新对账单状态为“已结算”.

## 4. 数据库设计 (MySQL)

### 4.1 系统基础表
*   `sys_user`: 用户表 (id, username, password, dept_id, status).
*   `sys_role`: 角色表 (id, role_name, role_code).
*   `sys_menu`: 菜单权限表 (id, parent_id, path, component, permission).
*   `sys_user_role`: 用户角色关联.
*   `sys_role_menu`: 角色菜单关联.
*   `sys_dept`: 部门表 (id, dept_name, parent_id).

### 4.2 业务核心表
*   `biz_monthly_plan`: 月度计划主表.
*   `biz_purchase_order`: 采购订单 (order_no, contract_id, supplier_id, total_amount, status).
*   `biz_order_detail`: 订单明细 (item_name, spec, qty, price).
*   `biz_contract`: 合同台账.
*   `biz_inbound`: 入库单 (关联 biz_purchase_order).
*   `biz_invoice`: 发票 (关联 biz_inbound).
*   `biz_reconciliation`: 对账单.
*   `biz_settlement`: 结算记录.
*   `biz_price_library`: 标准价格库.

## 5. 接口设计规范 (RESTful)
*   **通用响应**: `{ code: 200, msg: "success", data: ... }`
*   **分页**: `GET /api/v1/orders?page=1&size=10&keyword=...`
*   **新建**: `POST /api/v1/orders`
*   **更新**: `PUT /api/v1/orders/{id}`
*   **删除**: `DELETE /api/v1/orders/{id}`

## 6. AI 智能化设计
*   **后端**: 集成 LangChain for Java 或直接调用 LLM API.
*   **功能**:
    *   **Text-to-SQL**: 将自然语言转为 MyBatis-Plus `QueryWrapper` 或原生 SQL.
    *   **RAG**: 将上传的 PDF/Word 制度文档解析存入向量数据库 (如 Milvus 或 PgVector)，提供知识问答.

## 7. 安全设计
*   **认证**: Spring Security + JWT.
*   **密码**: BCrypt 加密存储.
*   **数据隔离**: MyBatis-Plus 租户插件 (如果需要多租户) 或 数据权限拦截器.
*   **审计**: AOP 记录关键操作日志 (操作人、IP、时间、变更内容).
